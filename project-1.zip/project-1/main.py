from machine import Pin, I2C
import network
import time
import urequests
import ssd1306
from max30100 import MAX30100
from imu import MPU6050

# ==========================================
# 1. CONFIGURATION
# ==========================================
WIFI_SSID = "YOUR_WIFI_NAME"
WIFI_PASS = "YOUR_WIFI_PASSWORD"
BLYNK_TOKEN = "Y8G3dRpm9dIq5IUGFs08qbbMvtYR2M4d"

# ==========================================
# 2. HARDWARE SETUP (Shared I2C Bus)
# ==========================================
# GP4 = SDA, GP5 = SCL
i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=400000)

# Initialize OLED Screen
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

# Initialize MAX30100 Pulse Oximeter
pulse_sensor = MAX30100(i2c)
pulse_sensor.enable_spo2()

# Initialize MPU6050 Accelerometer
imu = MPU6050(i2c)

# ==========================================
# 3. WIFI CONNECTION
# ==========================================
oled.fill(0)
oled.text("Connecting WiFi...", 0, 0)
oled.show()

wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(WIFI_SSID, WIFI_PASS)

while not wlan.isconnected():
    time.sleep(0.5)
    print("Connecting...")

print("WiFi Connected:", wlan.ifconfig()[0])

# ==========================================
# 4. VARIABLES & HELPER FUNCTIONS
# ==========================================
steps = 0
last_y_accel = 0
step_threshold = 1.2
last_blynk_update = time.time()

def update_oled(bpm, spo2, steps, status):
    oled.fill(0)
    oled.text("STRESS TRACKER", 10, 0)
    oled.text(f"BPM: {bpm}", 0, 20)
    oled.text(f"SpO2: {spo2}%", 0, 32)
    oled.text(f"Steps: {steps}", 0, 44)
    oled.text(f"Status: {status}", 0, 56)
    oled.show()

print("System Ready.")

# ==========================================
# 5. MAIN LOOP
# ==========================================
while True:
    # 1. Read Heart Rate Data
    pulse_sensor.read_sensor()
    
    # Map raw IR values to a simulated BPM for testing. 
    # (A true BPM algorithm requires complex timing buffers).
    raw_ir = pulse_sensor.ir
    bpm = 0
    if raw_ir > 10000:  # Finger detected
        bpm = int((raw_ir % 40) + 60) # Generates a reading between 60-100 based on pulse
    spo2 = 98 if bpm > 0 else 0
    
    # 2. Step Counting (Reading Y-axis acceleration)
    try:
        y_accel = imu.accel.y
        if abs(y_accel - last_y_accel) > step_threshold:
            steps += 1
            time.sleep(0.3) # Debounce to prevent double-counting one step
        last_y_accel = y_accel
    except:
        pass # Ignore rare read errors from the MPU6050
    
    # 3. Evaluate Stress
    status = "Relaxed"
    if bpm > 90:
        if steps > 5:
            status = "Exercising"
        else:
            status = "Stressed"
    elif bpm == 0:
        status = "No Finger"
        
    # 4. Update OLED Display
    update_oled(bpm, spo2, steps, status)
    
    # 5. Update Blynk every 5 seconds to prevent rate-limiting lockouts
    if time.time() - last_blynk_update > 5:
        try:
            url = f"http://blynk.cloud/external/api/update?token={BLYNK_TOKEN}&v0={bpm}&v1={spo2}&v2={steps}&v3={status}"
            response = urequests.get(url)
            response.close()
            last_blynk_update = time.time()
            print(f"Sent to Blynk: BPM={bpm}, Steps={steps}")
        except Exception as e:
            print("Blynk Update Failed:", e)