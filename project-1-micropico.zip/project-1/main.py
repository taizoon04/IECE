from machine import Pin, I2C
import network
import time
import ssd1306
from max30100 import MAX30100
from MPU6050 import MPU6050

try:
    import urequests
except ImportError:
    urequests = None

# ==========================================
# 1. CONFIGURATION
# ==========================================
WIFI_SSID = "YOUR_WIFI_NAME"
WIFI_PASS = "YOUR_WIFI_PASSWORD"
BLYNK_TOKEN = "Y8G3dRpm9dIq5IUGFs08qbbMvtYR2M4d"

# ==========================================
# 2. HARDWARE SETUP (Shared I2C Bus on GP4/GP5)
# ==========================================
# GP4 = SDA (Pin 6), GP5 = SCL (Pin 7) at 100kHz for breadboard stability
i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=100000)

# Active Buzzer on GP15 for High Stress Sound Alert
buzzer = Pin(15, Pin.OUT)
buzzer.value(0)

# Scan I2C Bus on Startup
detected = [hex(dev) for dev in i2c.scan()]
print("I2C devices detected on GP4/GP5:", detected)

# Initialize OLED Screen (0x3C)
oled = None
try:
    oled = ssd1306.SSD1306_I2C(128, 64, i2c)
    print("OLED (0x3C) initialized.")
except Exception as e:
    print("OLED init error (check wiring/solder on 0x3C):", e)

# Initialize MAX30100 Pulse Oximeter (0x57)
pulse_sensor = None
try:
    pulse_sensor = MAX30100(i2c)
    pulse_sensor.enable_spo2()
    print("MAX30100 (0x57) initialized.")
except Exception as e:
    print("MAX30100 init error (check wiring/solder on 0x57):", e)

# Initialize MPU6050 Accelerometer (0x68)
imu = None
try:
    imu = MPU6050(i2c)
    print("MPU6050 (0x68) initialized.")
except Exception as e:
    print("MPU6050 init error (check wiring/solder on 0x68):", e)


# ==========================================
# 3. WIFI CONNECTION (Auto-Skips if Offline)
# ==========================================
def connect_wifi():
    if WIFI_SSID == "YOUR_WIFI_NAME" or not WIFI_SSID:
        print("WiFi credentials not configured. Running in Offline Mode.")
        return False

    if oled:
        try:
            oled.fill(0)
            oled.text("Connecting WiFi...", 0, 0)
            oled.show()
        except Exception:
            pass

    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(WIFI_SSID, WIFI_PASS)

    attempts = 0
    while not wlan.isconnected() and attempts < 15:
        time.sleep(0.5)
        print("Connecting...")
        attempts += 1

    if wlan.isconnected():
        print("WiFi Connected:", wlan.ifconfig()[0])
        return True
    else:
        print("WiFi timeout. Continuing in Offline Mode.")
        return False


# ==========================================
# 4. VARIABLES & HELPER FUNCTIONS
# ==========================================
steps = 0
last_y_accel = 0.0
step_threshold = 0.35  # Threshold in g-units
last_blynk_update = time.time()


def update_oled(bpm, spo2, steps, status):
    if not oled:
        return
    try:
        oled.fill(0)
        oled.text("STRESS TRACKER", 10, 0)
        oled.text(f"BPM: {bpm}", 0, 20)
        oled.text(f"SpO2: {spo2}%", 0, 32)
        oled.text(f"Steps: {steps}", 0, 44)
        oled.text(f"Status: {status}", 0, 56)
        oled.show()
    except Exception as e:
        print("OLED update skipped:", e)


# ==========================================
# 5. MAIN LOOP
# ==========================================
wifi_connected = connect_wifi()
print("System Ready.")

while True:
    try:
        # 1. Read Heart Rate Data
        bpm = 0
        spo2 = 0
        if pulse_sensor:
            try:
                pulse_sensor.read_sensor()
                raw_ir = pulse_sensor.ir
                if raw_ir > 10000:
                    bpm = int((raw_ir % 40) + 60)
                    spo2 = 98
            except Exception as e:
                print("MAX30100 read error:", e)

        # 2. Step Counting (Reading Y-axis acceleration in g)
        if imu:
            try:
                y_accel = imu.accel.y
                if abs(y_accel - last_y_accel) > step_threshold:
                    steps += 1
                    time.sleep(0.3)  # Debounce step
                last_y_accel = y_accel
            except Exception as e:
                print("MPU6050 read error:", e)

        # 3. Evaluate Stress & Sound Alert
        status = "Relaxed"
        buzzer.value(0)
        if bpm > 90:
            if steps > 5:
                status = "Exercising"
                buzzer.value(0)
            else:
                status = "Stressed"
                buzzer.value(1)
        elif bpm == 0:
            status = "No Finger"
            buzzer.value(0)

        # 4. Update OLED Display
        update_oled(bpm, spo2, steps, status)

        # 5. Update Blynk every 5 seconds (if connected to WiFi)
        if wifi_connected and urequests and (time.time() - last_blynk_update > 5):
            try:
                url = f"http://blynk.cloud/external/api/update?token={BLYNK_TOKEN}&v0={bpm}&v1={spo2}&v2={steps}&v3={status}"
                response = urequests.get(url)
                response.close()
                last_blynk_update = time.time()
                print(f"Sent to Blynk: BPM={bpm}, Steps={steps}")
            except Exception as e:
                print("Blynk Update Failed:", e)

        time.sleep(0.1)

    except Exception as e:
        print("Main loop recovery:", e)
        time.sleep(0.5)
