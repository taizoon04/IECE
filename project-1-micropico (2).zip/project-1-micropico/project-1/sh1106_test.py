from machine import Pin, I2C  # type: ignore
import time
import framebuf  # type: ignore

i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=100000)
print("Scan:", [hex(d) for d in i2c.scan()])


class SH1106_I2C(framebuf.FrameBuffer):
    def __init__(self, width=128, height=64, i2c=None, addr=0x3C, col_offset=2):
        self.width = width
        self.height = height
        self.i2c = i2c
        self.addr = addr
        self.col_offset = col_offset
        self.pages = height // 8
        self.buffer = bytearray(self.pages * width)
        super().__init__(self.buffer, width, height, framebuf.MONO_VLSB)
        self.init_display()

    def write_cmd(self, cmd):
        self.i2c.writeto(self.addr, bytearray([0x00, cmd]))

    def init_display(self):
        for cmd in (
            0xAE,        # Display OFF
            0xD5, 0x80,  # Clock divide ratio / oscillator freq
            0xA8, 0x3F,  # Multiplex ratio (64)
            0xD3, 0x00,  # Display offset = 0
            0x40,        # Display start line = 0
            0xAD, 0x8B,  # DC-DC charge pump ON
            0xA1,        # Segment remap (flip horizontally if text is mirrored)
            0xC8,        # COM scan direction normal
            0xDA, 0x12,  # COM pins hardware config
            0x81, 0xCF,  # Contrast
            0xD9, 0x22,  # Pre-charge period
            0xDB, 0x35,  # VCOM deselect level
            0xA6,        # Normal (non-inverted) display
            0xA4,        # Output follows RAM content
            0xAF,        # Display ON
        ):
            self.write_cmd(cmd)
            time.sleep_ms(2)
        self.fill(0)
        self.show()

    def show(self):
        for page in range(self.pages):
            col = self.col_offset
            self.write_cmd(0xB0 | page)          # Set page address
            self.write_cmd(0x00 | (col & 0x0F))  # Set lower column address
            self.write_cmd(0x10 | ((col >> 4) & 0x0F))  # Set higher column address
            start = page * self.width
            end = start + self.width
            chunk = bytearray(b"\x40") + self.buffer[start:end]
            self.i2c.writeto(self.addr, chunk)


time.sleep_ms(150)
oled = SH1106_I2C(128, 64, i2c, addr=0x3C, col_offset=2)
oled.fill(0)
oled.text("SH1106 OK!", 10, 8, 1)
oled.text("PICO W GP4/GP5", 10, 24, 1)
oled.text("READY", 10, 42, 1)
oled.show()
print("SH1106 test complete.")