import time
from machine import I2C  # type: ignore

# MAX30100 Registers
INT_STATUS   = 0x00
INT_ENABLE   = 0x01
FIFO_WR_PTR  = 0x02
OVRFLOW_CTR  = 0x03
FIFO_RD_PTR  = 0x04
FIFO_DATA    = 0x05
MODE_CONFIG  = 0x06
SPO2_CONFIG  = 0x07
LED_CONFIG   = 0x09

class MAX30100:
    def __init__(self, i2c, address=0x57):
        self.i2c = i2c
        self.address = address
        self.ir = 0
        self.red = 0
        self.reset()
        self.set_mode()
        self.clear_fifo()

    def write_register(self, reg, value):
        self.i2c.writeto_mem(self.address, reg, bytes([value]))

    def read_register(self, reg):
        return self.i2c.readfrom_mem(self.address, reg, 1)[0]

    def reset(self):
        # Soft reset the MAX30100
        self.write_register(MODE_CONFIG, 0x40)
        time.sleep(0.1)

    def set_mode(self):
        # SpO2 mode, 50 samples/sec, 16-bit ADC resolution, LED current ~27.1mA
        self.write_register(MODE_CONFIG, 0x03)
        self.write_register(SPO2_CONFIG, 0x27)
        self.write_register(LED_CONFIG, 0x77)
        self.write_register(INT_ENABLE, 0x00)

    def clear_fifo(self):
        # Reset internal pointers to unfreeze the data buffer
        self.write_register(FIFO_WR_PTR, 0x00)
        self.write_register(OVRFLOW_CTR, 0x00)
        self.write_register(FIFO_RD_PTR, 0x00)

    def enable_spo2(self):
        self.set_mode()

    def read_sensor(self):
        try:
            wr_ptr = self.read_register(FIFO_WR_PTR)
            rd_ptr = self.read_register(FIFO_RD_PTR)
            
            if wr_ptr != rd_ptr:
                num_samples = (wr_ptr - rd_ptr) & 0x0F
                if num_samples > 0:
                    data = self.i2c.readfrom_mem(self.address, FIFO_DATA, 4 * num_samples)
                    last_idx = (num_samples - 1) * 4
                    self.ir = (data[last_idx] << 8) | data[last_idx + 1]
                    self.red = (data[last_idx + 2] << 8) | data[last_idx + 3]
                    
                    # Sync read pointer to clear buffer
                    self.write_register(FIFO_RD_PTR, wr_ptr)
        except OSError:
            # Re-initialize pointers if an I2C glitch occurs
            self.clear_fifo()