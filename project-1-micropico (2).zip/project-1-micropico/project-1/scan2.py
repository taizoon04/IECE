from machine import Pin, I2C
import time

# Initialize I2C bus on GP4 (SDA) and GP5 (SCL)
i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=100000)

print("Scanning I2C bus on GP4 and GP5...")
devices = i2c.scan()

if devices:
    print("Devices found (Hexadecimal):", [hex(device) for decimal in devices for device in [decimal]])
else:
    print("No I2C devices found! Check your VCC, GND, SDA, and SCL wiring.")