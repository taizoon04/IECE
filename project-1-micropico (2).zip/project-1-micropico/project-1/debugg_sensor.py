from machine import Pin, I2C
import time

# Initialize I2C0 on GP4/GP5
i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=100000)
ADDR = 0x57

print("--- MAX30100 REGISTER DIAGNOSTIC ---")

try:
    # 1. Read Mode Configuration Register (Default should change after write)
    mode_val = i2c.readfrom_mem(ADDR, 0x06, 1)[0]
    print(f"Current MODE_CONFIG register (0x06): {hex(mode_val)}")

    # 2. Force write SpO2 mode (0x03)
    i2c.writeto_mem(ADDR, 0x06, b'\x03')
    time.sleep(0.05)
    
    # 3. Set LED Current (Register 0x09) to medium-high power (50mA)
    i2c.writeto_mem(ADDR, 0x09, b'\x77')
    time.sleep(0.05)

    # 4. Read FIFO Pointers
    wr_ptr = i2c.readfrom_mem(ADDR, 0x02, 1)[0]
    rd_ptr = i2c.readfrom_mem(ADDR, 0x04, 1)[0]
    print(f"FIFO Write Pointer (0x02): {wr_ptr}")
    print(f"FIFO Read Pointer (0x04): {rd_ptr}")

    print("Diagnostic complete. If pointers change when you touch the sensor, the hardware is alive!")

except Exception as e:
    print("I2C Communication Error during debug:", e)