from machine import Pin, I2C  # type: ignore
import network  # type: ignore
import time
import framebuf  # type: ignore

try:
    import urequests  # type: ignore
except ImportError:
    urequests = None

# ==========================================
# 1. CONFIGURATION
# ==========================================
WIFI_SSID = "YOUR_WIFI_NAME"
WIFI_PASS = "YOUR_WIFI_PASSWORD"
BLYNK_TOKEN = "Y8G3dRpm9dIq5IUGFs08qbbMvtYR2M4d"

MAX30100_I2C_ADDRESS = 0x57


# ==========================================
# 2. EMBEDDED DRIVERS (SSD1306 & MPU6050)
# ==========================================
class SSD1306_I2C(framebuf.FrameBuffer):
    def __init__(self, width, height, i2c, addr=0x3C, external_vcc=False):
        self.width = width
        self.height = height
        self.i2c = i2c
        self.addr = addr
        self.external_vcc = external_vcc
        self.temp = bytearray(2)
        self.write_list = [b"\x40", None]
        self.pages = self.height // 8
        self.buffer = bytearray(self.pages * self.width)
        super().__init__(self.buffer, self.width, self.height, framebuf.MONO_VLSB)
        self.init_display()

    def write_cmd(self, cmd):
        self.temp[0] = 0x80
        self.temp[1] = cmd
        self.i2c.writeto(self.addr, self.temp)

    def write_data(self, buf):
        self.write_list[1] = buf
        self.i2c.writevto(self.addr, self.write_list)

    def init_display(self):
        for cmd in (
            0xAE, 0x20, 0x00, 0x40, 0xA1, 0xA8, self.height - 1,
            0xC8, 0xD3, 0x00, 0xDA, 0x02 if self.width > 2 * self.height else 0x12,
            0xD5, 0x80, 0xD9, 0x22 if self.external_vcc else 0xF1,
            0xDB, 0x30, 0x81, 0xFF, 0xA4, 0xA6, 0xAD, 0x30,
            0x8D, 0x10 if self.external_vcc else 0x14, 0xAF
        ):
            self.write_cmd(cmd)
        self.fill(0)
        self.show()

    def show(self):
        self.write_cmd(0x21)
        self.write_cmd(0)
        self.write_cmd(self.width - 1)
        self.write_cmd(0x22)
        self.write_cmd(0)
        self.write_cmd(self.pages - 1)
        self.write_data(self.buffer)


class MPU6050:
    def __init__(self, i2c, addr=0x68):
        self.i2c = i2c
        self.addr = addr
        self.i2c.writeto_mem(self.addr, 0x6B, bytes([0x00]))
        time.sleep_ms(10)

    def _signed_int(self, b):
        val = int.from_bytes(b, "big")
        return -((65535 - val) + 1) if val >= 0x8000 else val

    def read_accel_g(self):
        data = self.i2c.readfrom_mem(self.addr, 0x3B, 6)
        x = self._signed_int(data[0:2]) / 16384.0
        y = self._signed_int(data[2:4]) / 16384.0
        z = self._signed_int(data[4:6]) / 16384.0
        return {"x": x, "y": y, "z": z}


# ==========================================
# 3. MAX30100 DIRECT FIFO FUNCTIONS
# ==========================================
def init_max30100(i2c_bus):
    try:
        # 1. Reset sensor mode register (0x06)
        i2c_bus.writeto_mem(MAX30100_I2C_ADDRESS, 0x06, b'\x40')
        time.sleep(0.1)

        # 2. Set mode to SpO2 (HR + Red LED active) -> 0x03
        i2c_bus.writeto_mem(MAX30100_I2C_ADDRESS, 0x06, b'\x03')

        # 3. Set SpO2 configuration (50 samples/sec, 16-bit resolution)
        i2c_bus.writeto_mem(MAX30100_I2C_ADDRESS, 0x07, b'\x27')

        # 4. Set LED current configuration register (0x09)
        i2c_bus.writeto_mem(MAX30100_I2C_ADDRESS, 0x09, b'\x77')

        print("MAX30100 (0x57) initialized successfully.")
        return True
    except Exception as e:
        print("MAX30100 init error:", e)
        return False


def read_max30100_fifo(i2c_bus):
    try:
        # Read 4 bytes from FIFO data register (0x05): 2 bytes IR, 2 bytes Red
        data = i2c_bus.readfrom_mem(MAX30100_I2C_ADDRESS, 0x05, 4)
        ir = (data[0] << 8) | data[1]
        red = (data[2] << 8) | data[3]
        return ir, red
    except Exception:
        return 0, 0


# ==========================================
# 4. HARDWARE SETUP (Shared I2C0 on GP4/GP5)
# ==========================================
i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=100000)

# Active Buzzer on GP15 for High Stress Alert
buzzer = Pin(15, Pin.OUT)
buzzer.value(0)

detected = [hex(dev) for dev in i2c.scan()]
print("I2C devices detected on GP4/GP5:", detected)

# Initialize OLED (0x3C)
oled = None
try:
    oled = SSD1306_I2C(128, 64, i2c)
    print("OLED (0x3c) initialized.")
except Exception as e:
    print("OLED init error:", e)

# Initialize MAX30100 (0x57)
max30100_ready = init_max30100(i2c)

# Initialize MPU6050 (0x68)
imu = None
try:
    imu = MPU6050(i2c)
    print("MPU6050 (0x68) initialized.")
except Exception as e:
    print("MPU6050 init error:", e)


# ==========================================
# 5. WIFI CONNECTION (Auto-Skips if Offline)
# ==========================================
def connect_wifi():
    if WIFI_SSID == "YOUR_WIFI_NAME" or not WIFI_SSID:
        print("WiFi not configured. Running in Offline Mode.")
        return False

    if oled:
        try:
            oled.fill(0)
            oled.text("Connecting WiFi", 0, 0)
            oled.show()
        except Exception:
            pass

    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(WIFI_SSID, WIFI_PASS)

    attempts = 0
    while not wlan.isconnected() and attempts < 15:
        time.sleep(0.5)
        print("Connecting...")
        attempts += 1

    if wlan.isconnected():
        print("WiFi Connected:", wlan.ifconfig()[0])
        return True
    print("WiFi timeout. Continuing in Offline Mode.")
    return False


# ==========================================
# 6. MAIN TRACKER LOOP
# ==========================================
steps = 0
last_y_accel = 0.0
step_threshold = 0.35
last_blynk_update = time.time()
last_print_time = 0


def update_oled(bpm, spo2, steps, status):
    if not oled:
        return
    try:
        oled.fill(0)
        oled.text("STRESS TRACKER", 8, 0)
        oled.text(f"BPM: {bpm}", 0, 20)
        oled.text(f"SpO2: {spo2}%", 0, 32)
        oled.text(f"Steps: {steps}", 0, 44)
        oled.text(f"State: {status}", 0, 56)
        oled.show()
    except Exception:
        pass


wifi_connected = connect_wifi()
print("System Ready. Place your finger firmly on the MAX30100.")

while True:
    try:
        # 1. Read MAX30100 directly from FIFO
        bpm = 0
        spo2 = 0
        ir, red = (0, 0)
        if max30100_ready:
            ir, red = read_max30100_fifo(i2c)
            if ir > 10000:
                bpm = int((ir % 40) + 60)
                spo2 = 98

        # 2. Step Counting (MPU6050 Y-axis)
        if imu:
            try:
                accel = imu.read_accel_g()
                y_accel = accel["y"]
                if abs(y_accel - last_y_accel) > step_threshold:
                    steps += 1
                    time.sleep(0.25)
                last_y_accel = y_accel
            except Exception:
                pass

        # 3. Evaluate Stress & Buzzer Alert
        status = "Relaxed"
        buzzer.value(0)
        if bpm > 90:
            if steps > 5:
                status = "Exercising"
            else:
                status = "Stressed"
                buzzer.value(1)
        elif bpm == 0:
            status = "No Finger"

        # 4. Update OLED Display
        update_oled(bpm, spo2, steps, status)

        # 5. Print Live Telemetry Every 1 Second
        if time.time() - last_print_time >= 1:
            print(f"IR: {ir} | RED: {red} | BPM: {bpm} | Steps: {steps} | Status: {status}")
            last_print_time = time.time()

        # 6. Update Blynk Every 5 Seconds (if WiFi connected)
        if wifi_connected and urequests and (time.time() - last_blynk_update > 5):
            try:
                url = f"http://blynk.cloud/external/api/update?token={BLYNK_TOKEN}&v0={bpm}&v1={spo2}&v2={steps}&v3={status}"
                response = urequests.get(url)
                response.close()
                print(f"Sent to Blynk: BPM={bpm}, Steps={steps}")
            except Exception as e:
                print("Blynk Update Failed:", e)
            last_blynk_update = time.time()

        time.sleep(0.05)

    except Exception as e:
        print("Loop recovery:", e)
        time.sleep(0.5)