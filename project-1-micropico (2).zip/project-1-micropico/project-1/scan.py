from machine import Pin, I2C
import time

i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=100000)

print("Scanning I2C0 on GP4 (SDA) and GP5 (SCL)...")
devices = i2c.scan()
print("I2C addresses found:", [hex(d) for d in devices])
# Expected: ['0x3c' (OLED), '0x57' (MAX30100), '0x68' (MPU6050)]
