from machine import Pin, I2C  # type: ignore
import network  # type: ignore
import time
import math
import framebuf  # type: ignore

try:
    import urequests  # type: ignore
except ImportError:
    urequests = None

# ==========================================
# 1. CONFIGURATION
# ==========================================
WIFI_SSID = "HU-Portal"
WIFI_PASS = "Habib786&*^"
BLYNK_TOKEN = "Y8G3dRpm9dIq5IUGFs08qbbMvtYR2M4d"

MAX30100_I2C_ADDRESS = 0x57
OLED_I2C_ADDRESS = 0x3C
SH1106_COL_OFFSET = 2
IR_FINGER_THRESHOLD = 10000
STRESS_BPM_THRESHOLD = 90
RECENT_WINDOW_MS = 15000
RECENT_STEPS_THRESHOLD = 4
OLED_REFRESH_MS = 150


# ==========================================
# 2. EMBEDDED DRIVERS (SH1106 & MPU6050)
# ==========================================
class SH1106_I2C(framebuf.FrameBuffer):
    def __init__(self, width=128, height=64, i2c=None, addr=0x3C, col_offset=2):
        self.width = width
        self.height = height
        self.i2c = i2c
        self.addr = addr
        self.col_offset = col_offset
        self.pages = height // 8
        self.buffer = bytearray(self.pages * width)
        super().__init__(self.buffer, width, height, framebuf.MONO_VLSB)
        self.init_display()

    def write_cmd(self, cmd):
        self.i2c.writeto(self.addr, bytearray([0x00, cmd]))

    def init_display(self):
        for cmd in (
            0xAE,        # Display OFF
            0xD5, 0x80,  # Clock divide ratio / oscillator freq
            0xA8, 0x3F,  # Multiplex ratio (64)
            0xD3, 0x00,  # Display offset = 0
            0x40,        # Display start line = 0
            0xAD, 0x8B,  # DC-DC charge pump ON
            0xA1,        # Segment remap
            0xC8,        # COM scan direction normal
            0xDA, 0x12,  # COM pins hardware config
            0x81, 0xCF,  # Contrast
            0xD9, 0x22,  # Pre-charge period
            0xDB, 0x35,  # VCOM deselect level
            0xA6,        # Normal (non-inverted) display
            0xA4,        # Output follows RAM content
            0xAF,        # Display ON
        ):
            self.write_cmd(cmd)
            time.sleep_ms(2)
        self.fill(0)
        self.show()

    def show(self):
        for page in range(self.pages):
            col = self.col_offset
            self.write_cmd(0xB0 | page)
            self.write_cmd(0x00 | (col & 0x0F))
            self.write_cmd(0x10 | ((col >> 4) & 0x0F))
            start = page * self.width
            end = start + self.width
            chunk = bytearray(b"\x40") + self.buffer[start:end]
            self.i2c.writeto(self.addr, chunk)


class MPU6050:
    def __init__(self, i2c, addr=0x68):
        self.i2c = i2c
        self.addr = addr
        self.i2c.writeto_mem(self.addr, 0x6B, bytes([0x00]))
        time.sleep_ms(10)

    def _signed_int(self, b):
        val = int.from_bytes(b, "big")
        return -((65535 - val) + 1) if val >= 0x8000 else val

    def read_accel_g(self):
        data = self.i2c.readfrom_mem(self.addr, 0x3B, 6)
        x = self._signed_int(data[0:2]) / 16384.0
        y = self._signed_int(data[2:4]) / 16384.0
        z = self._signed_int(data[4:6]) / 16384.0
        return {"x": x, "y": y, "z": z}


# ==========================================
# 3. MAX30100 DIRECT FIFO FUNCTIONS
# ==========================================
def init_max30100(i2c_bus):
    try:
        i2c_bus.writeto_mem(MAX30100_I2C_ADDRESS, 0x06, b"\x40")
        time.sleep(0.1)
        i2c_bus.writeto_mem(MAX30100_I2C_ADDRESS, 0x06, b"\x03")
        i2c_bus.writeto_mem(MAX30100_I2C_ADDRESS, 0x07, b"\x27")
        i2c_bus.writeto_mem(MAX30100_I2C_ADDRESS, 0x09, b"\x77")
        print("MAX30100 (0x57) initialized successfully.")
        return True
    except Exception as e:
        print("MAX30100 init error:", e)
        return False


def read_max30100_fifo(i2c_bus):
    try:
        data = i2c_bus.readfrom_mem(MAX30100_I2C_ADDRESS, 0x05, 4)
        ir = (data[0] << 8) | data[1]
        red = (data[2] << 8) | data[3]
        return ir, red
    except Exception:
        return 0, 0


# ==========================================
# 4. SIGNAL PROCESSING (BPM & WRIST STEPS)
# ==========================================
class HeartRateEstimator:
    def __init__(self, debug=False):
        self.debug = debug
        self.dc_avg = None
        self.prev_ac = 0.0
        self.last_peak_ms = 0
        self.armed_for_next_peak = True
        self.bpm = 0
        self.beat_intervals_ms = []
        self.peak_threshold = 4.0
        self.min_ibi_ms = 600   # 100 BPM max normal spacing
        self.max_ibi_ms = 1500  # 40 BPM min spacing

    def reset(self):
        self.dc_avg = None
        self.prev_ac = 0.0
        self.last_peak_ms = 0
        self.armed_for_next_peak = True
        self.bpm = 0
        self.beat_intervals_ms = []

    def _median_ibi(self):
        ordered = sorted(self.beat_intervals_ms)
        n = len(ordered)
        mid = n // 2
        if n % 2 == 1:
            return float(ordered[mid])
        return (ordered[mid - 1] + ordered[mid]) / 2.0

    def update(self, ir_val, now_ms):
        if ir_val <= IR_FINGER_THRESHOLD:
            self.reset()
            return 0

        if self.dc_avg is None:
            self.dc_avg = float(ir_val)
        else:
            self.dc_avg = (0.96 * self.dc_avg) + (0.04 * ir_val)

        ac_signal = ir_val - self.dc_avg

        # Re-arm detector only after signal dips back below zero
        if ac_signal < 0.0:
            self.armed_for_next_peak = True

        if (
            self.armed_for_next_peak
            and self.prev_ac >= self.peak_threshold
            and ac_signal < self.prev_ac
        ):
            self.armed_for_next_peak = False
            if self.last_peak_ms == 0:
                self.last_peak_ms = now_ms
            else:
                ibi_ms = time.ticks_diff(now_ms, self.last_peak_ms)
                if self.min_ibi_ms <= ibi_ms <= self.max_ibi_ms:
                    self.beat_intervals_ms.append(ibi_ms)
                    if len(self.beat_intervals_ms) > 7:
                        self.beat_intervals_ms.pop(0)
                    if len(self.beat_intervals_ms) >= 2:
                        med_ibi = self._median_ibi()
                        self.bpm = int(round(60000.0 / med_ibi))
                    self.last_peak_ms = now_ms
                elif ibi_ms > self.max_ibi_ms:
                    self.last_peak_ms = now_ms

        self.prev_ac = ac_signal

        if self.debug:
            print(f"IR: {ir_val} | AC: {ac_signal:.1f} | BPM: {self.bpm}")

        if self.last_peak_ms > 0 and time.ticks_diff(now_ms, self.last_peak_ms) > 5000:
            self.bpm = 0
            self.beat_intervals_ms = []

        return self.bpm


class WristStepDetector:
    def __init__(self):
        self.min_g = 0.25          # Ignore subtle hand/finger tremors
        self.max_g = 1.25          # Ignore sharp table taps or sudden jerks
        self.min_step_ms = 350     # Fastest walking/jogging cadence
        self.max_step_ms = 1100    # Slowest walking cadence
        self.last_candidate_ms = 0
        self.rhythm_streak = 0
        self.total_steps = 0
        self.recent_step_times_ms = []

    def update(self, accel_dict, now_ms, window_ms=15000):
        mag = math.sqrt(
            accel_dict["x"] ** 2 + accel_dict["y"] ** 2 + accel_dict["z"] ** 2
        )
        dynamic_g = abs(mag - 1.0)

        if self.min_g <= dynamic_g <= self.max_g:
            dt = time.ticks_diff(now_ms, self.last_candidate_ms)
            if self.min_step_ms <= dt <= self.max_step_ms:
                self.rhythm_streak += 1
                self.last_candidate_ms = now_ms

                if self.rhythm_streak >= 3:
                    self.total_steps += 1
                    self.recent_step_times_ms.append(now_ms)
            elif dt > self.max_step_ms:
                self.rhythm_streak = 1
                self.last_candidate_ms = now_ms

        self.recent_step_times_ms = [
            t for t in self.recent_step_times_ms
            if time.ticks_diff(now_ms, t) <= window_ms
        ]
        return self.total_steps, len(self.recent_step_times_ms)


# ==========================================
# 5. HARDWARE SETUP (Shared I2C0 on GP4/GP5)
# ==========================================
i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=100000)

buzzer = Pin(15, Pin.OUT)
buzzer.value(0)

detected = [hex(dev) for dev in i2c.scan()]
print("I2C devices detected on GP4/GP5:", detected)

oled = None
time.sleep_ms(120)
for attempt in range(3):
    try:
        oled = SH1106_I2C(128, 64, i2c, addr=OLED_I2C_ADDRESS, col_offset=SH1106_COL_OFFSET)
        print("SH1106 OLED (0x3c) initialized.")
        break
    except Exception as e:
        print(f"OLED init attempt {attempt + 1} failed:", e)
        time.sleep_ms(150)

max30100_ready = init_max30100(i2c)

imu = None
try:
    imu = MPU6050(i2c)
    print("MPU6050 (0x68) initialized.")
except Exception as e:
    print("MPU6050 init error:", e)


# ==========================================
# 6. WIFI CONNECTION (Auto-Skips if Offline)
# ==========================================
def connect_wifi():
    if WIFI_SSID == "YOUR_WIFI_NAME" or not WIFI_SSID:
        print("WiFi not configured. Running in Offline Mode.")
        return False

    if oled:
        try:
            oled.fill(0)
            oled.text("Connecting WiFi", 0, 0, 1)
            oled.show()
        except Exception as e:
            print("OLED WiFi screen error:", e)

    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(WIFI_SSID, WIFI_PASS)

    attempts = 0
    while not wlan.isconnected() and attempts < 15:
        time.sleep(0.5)
        print("Connecting...")
        attempts += 1

    if wlan.isconnected():
        print("WiFi Connected:", wlan.ifconfig()[0])
        return True
    print("WiFi timeout. Continuing in Offline Mode.")
    return False


# ==========================================
# 7. MAIN TRACKER LOOP
# ==========================================
total_steps = 0
recent_steps = 0
last_oled_ms = 0
last_blynk_update = time.time()
last_print_time = 0

hr_estimator = HeartRateEstimator(debug=False)
step_detector = WristStepDetector()


def update_oled(bpm, spo2, steps, recent_count, status):
    if not oled:
        return
    try:
        oled.fill(0)
        oled.text("STRESS TRACKER", 8, 0, 1)
        oled.text(f"BPM: {bpm}", 0, 18, 1)
        oled.text(f"SpO2: {spo2}%", 0, 29, 1)
        oled.text(f"Steps: {steps} ({recent_count}r)", 0, 40, 1)
        oled.text(f"State: {status}", 0, 52, 1)
        oled.show()
    except Exception as e:
        print("OLED update error:", e)


wifi_connected = connect_wifi()
print("System Ready. Place your finger gently and steadily on the MAX30100.")

while True:
    try:
        now_ms = time.ticks_ms()

        ir, red = (0, 0)
        bpm = 0
        spo2 = 0
        if max30100_ready:
            ir, red = read_max30100_fifo(i2c)
            bpm = hr_estimator.update(ir, now_ms)
            if ir > IR_FINGER_THRESHOLD:
                spo2 = 98

        if imu:
            try:
                accel = imu.read_accel_g()
                total_steps, recent_steps = step_detector.update(
                    accel, now_ms, RECENT_WINDOW_MS
                )
            except Exception as e:
                print("MPU6050 read error:", e)

        status = "Relaxed"
        buzzer.value(0)
        if ir <= IR_FINGER_THRESHOLD:
            status = "No Finger"
        elif bpm > STRESS_BPM_THRESHOLD:
            if recent_steps >= RECENT_STEPS_THRESHOLD:
                status = "Exercising"
            else:
                status = "Stressed"
                buzzer.value(1)

        if time.ticks_diff(now_ms, last_oled_ms) >= OLED_REFRESH_MS:
            update_oled(bpm, spo2, total_steps, recent_steps, status)
            last_oled_ms = now_ms

        if time.time() - last_print_time >= 1:
            print(
                f"IR: {ir} | RED: {red} | BPM: {bpm} | "
                f"Steps: {total_steps} (15s: {recent_steps}) | Status: {status}"
            )
            last_print_time = time.time()

        if wifi_connected and urequests and (time.time() - last_blynk_update > 5):
            try:
                url = (
                    f"http://blynk.cloud/external/api/update?token={BLYNK_TOKEN}"
                    f"&v0={bpm}&v1={spo2}&v2={total_steps}&v3={status}"
                )
                response = urequests.get(url)
                response.close()
                print(f"Sent to Blynk: BPM={bpm}, Steps={total_steps}")
            except Exception as e:
                print("Blynk Update Failed:", e)
            last_blynk_update = time.time()

        time.sleep(0.02)

    except Exception as e:
        print("Loop recovery:", e)
        time.sleep(0.5)