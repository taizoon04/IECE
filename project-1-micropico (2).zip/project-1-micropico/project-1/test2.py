from machine import Pin, I2C
import time

# Initialize I2C on GP4/GP5
i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=100000)

print("Scanning I2C bus...")
devices = i2c.scan()
print("Found devices:", [hex(d) for d in devices])

if 0x57 in devices:
    print("MAX30100 detected at 0x57! Attempting direct register read...")
    # Try reading the part ID register (should respond)
    try:
        # Write to mode config to wake it up
        i2c.writeto_mem(0x57, 0x06, b'\x03')
        time.sleep(0.1)
        print("Sensor woken up successfully.")
    except Exception as e:
        print("Failed to write to MAX30100 memory:", e)
else:
    print("ERROR: 0x57 (MAX30100) is NOT found on the I2C bus! Check your SDA, SCL, VCC, and GND wires.")