# Class to read data from the (GY-521) MPU6050 Accelerometer/Gyro Module
# Converted for Raspberry Pi Pico W (MicroPython / MicroPico)

from math import sqrt, atan2
from machine import Pin, I2C, SoftI2C
from time import sleep_ms

error_msg = "\nError \n"
i2c_err_str = "Pico W could not communicate with MPU6050 at address 0x{:02X}, check wiring"

# Global Variables
_GRAVITIY_MS2 = 9.80665

# Scale Modifiers
_ACC_SCLR_2G = 16384.0
_ACC_SCLR_4G = 8192.0
_ACC_SCLR_8G = 4096.0
_ACC_SCLR_16G = 2048.0

_GYR_SCLR_250DEG = 131.0
_GYR_SCLR_500DEG = 65.5
_GYR_SCLR_1000DEG = 32.8
_GYR_SCLR_2000DEG = 16.4

# Pre-defined ranges
_ACC_RNG_2G = 0x00
_ACC_RNG_4G = 0x08
_ACC_RNG_8G = 0x10
_ACC_RNG_16G = 0x18

_GYR_RNG_250DEG = 0x00
_GYR_RNG_500DEG = 0x08
_GYR_RNG_1000DEG = 0x10
_GYR_RNG_2000DEG = 0x18

# MPU-6050 Registers
_PWR_MGMT_1 = 0x6B
_ACCEL_XOUT0 = 0x3B
_TEMP_OUT0 = 0x41
_GYRO_XOUT0 = 0x43
_ACCEL_CONFIG = 0x1C
_GYRO_CONFIG = 0x1B

_maxFails = 3
_MPU6050_ADDRESS = 0x68


def signedIntFromBytes(x, endian="big"):
    y = int.from_bytes(x, endian)
    if y >= 0x8000:
        return -((65535 - y) + 1)
    else:
        return y


class _AccelVector:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z


class MPU6050(object):
    def __init__(self, bus=None, freq=100000, sda=None, scl=None, addr=_MPU6050_ADDRESS):
        self._failCount = 0
        self._terminatingFailCount = 0

        # Use passed I2C bus if provided; otherwise default to Pico W I2C0 (GP4=SDA, GP5=SCL)
        if bus is not None and hasattr(bus, "writeto_mem"):
            self.i2c = bus
        else:
            sda_pin = Pin(4) if sda is None else (sda if isinstance(sda, Pin) else Pin(sda))
            scl_pin = Pin(5) if scl is None else (scl if isinstance(scl, Pin) else Pin(scl))
            bus_id = bus if isinstance(bus, int) else 0
            self.i2c = I2C(bus_id, sda=sda_pin, scl=scl_pin, freq=freq or 100000)

        self.addr = addr
        try:
            # Wake up the MPU-6050 since it starts in sleep mode
            self.i2c.writeto_mem(self.addr, _PWR_MGMT_1, bytes([0x00]))
            sleep_ms(10)
        except Exception as e:
            print(i2c_err_str.format(self.addr))
            print(error_msg)
            raise e
        self._accel_range = self.get_accel_range(True)
        self._gyro_range = self.get_gyro_range(True)

    @property
    def accel(self):
        # Provides imu.accel.x / imu.accel.y / imu.accel.z in g-units
        d = self.read_accel_data(g=True)
        return _AccelVector(d["x"], d["y"], d["z"])

    def get_accel(self, g=True):
        return self.read_accel_data(g=g)

    def _readData(self, register):
        failCount = 0
        while failCount < _maxFails:
            try:
                sleep_ms(10)
                data = self.i2c.readfrom_mem(self.addr, register, 6)
                break
            except Exception:
                failCount += 1
                self._failCount += 1
                if failCount >= _maxFails:
                    self._terminatingFailCount += 1
                    print(i2c_err_str.format(self.addr))
                    return {"x": 0.0, "y": 0.0, "z": 0.0}
        x = signedIntFromBytes(data[0:2])
        y = signedIntFromBytes(data[2:4])
        z = signedIntFromBytes(data[4:6])
        return {"x": x, "y": y, "z": z}

    def read_temperature(self):
        try:
            rawData = self.i2c.readfrom_mem(self.addr, _TEMP_OUT0, 2)
            raw_temp = signedIntFromBytes(rawData, "big")
        except Exception:
            print(i2c_err_str.format(self.addr))
            return float("NaN")
        actual_temp = (raw_temp / 340) + 36.53
        return actual_temp

    def set_accel_range(self, accel_range):
        self.i2c.writeto_mem(self.addr, _ACCEL_CONFIG, bytes([accel_range]))
        self._accel_range = accel_range

    def get_accel_range(self, raw=False):
        raw_data = self.i2c.readfrom_mem(self.addr, _ACCEL_CONFIG, 2)
        if raw is True:
            return raw_data[0]
        if raw_data[0] == _ACC_RNG_2G:
            return 2
        elif raw_data[0] == _ACC_RNG_4G:
            return 4
        elif raw_data[0] == _ACC_RNG_8G:
            return 8
        elif raw_data[0] == _ACC_RNG_16G:
            return 16
        return -1

    def read_accel_data(self, g=False):
        accel_data = self._readData(_ACCEL_XOUT0)
        accel_range = self._accel_range
        if accel_range == _ACC_RNG_2G:
            scaler = _ACC_SCLR_2G
        elif accel_range == _ACC_RNG_4G:
            scaler = _ACC_SCLR_4G
        elif accel_range == _ACC_RNG_8G:
            scaler = _ACC_SCLR_8G
        elif accel_range == _ACC_RNG_16G:
            scaler = _ACC_SCLR_16G
        else:
            scaler = _ACC_SCLR_2G

        x = accel_data["x"] / scaler
        y = accel_data["y"] / scaler
        z = accel_data["z"] / scaler

        if g is True:
            return {"x": x, "y": y, "z": z}
        return {
            "x": x * _GRAVITIY_MS2,
            "y": y * _GRAVITIY_MS2,
            "z": z * _GRAVITIY_MS2,
        }

    def read_accel_abs(self, g=False):
        d = self.read_accel_data(g)
        return sqrt(d["x"] ** 2 + d["y"] ** 2 + d["z"] ** 2)

    def set_gyro_range(self, gyro_range):
        self.i2c.writeto_mem(self.addr, _GYRO_CONFIG, bytes([gyro_range]))
        self._gyro_range = gyro_range

    def get_gyro_range(self, raw=False):
        raw_data = self.i2c.readfrom_mem(self.addr, _GYRO_CONFIG, 2)
        if raw is True:
            return raw_data[0]
        if raw_data[0] == _GYR_RNG_250DEG:
            return 250
        elif raw_data[0] == _GYR_RNG_500DEG:
            return 500
        elif raw_data[0] == _GYR_RNG_1000DEG:
            return 1000
        elif raw_data[0] == _GYR_RNG_2000DEG:
            return 2000
        return -1

    def read_gyro_data(self):
        gyro_data = self._readData(_GYRO_XOUT0)
        gyro_range = self._gyro_range
        if gyro_range == _GYR_RNG_250DEG:
            scaler = _GYR_SCLR_250DEG
        elif gyro_range == _GYR_RNG_500DEG:
            scaler = _GYR_SCLR_500DEG
        elif gyro_range == _GYR_RNG_1000DEG:
            scaler = _GYR_SCLR_1000DEG
        elif gyro_range == _GYR_RNG_2000DEG:
            scaler = _GYR_SCLR_2000DEG
        else:
            scaler = _GYR_SCLR_250DEG

        return {
            "x": gyro_data["x"] / scaler,
            "y": gyro_data["y"] / scaler,
            "z": gyro_data["z"] / scaler,
        }

    def read_angle(self):
        a = self.read_accel_data()
        x = atan2(a["y"], a["z"])
        y = atan2(-a["x"], a["z"])
        return {"x": x, "y": y}
